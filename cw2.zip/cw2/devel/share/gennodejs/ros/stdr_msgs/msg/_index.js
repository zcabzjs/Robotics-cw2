
"use strict";

let RfidTagVector = require('./RfidTagVector.js');
let ThermalSensorMsg = require('./ThermalSensorMsg.js');
let RfidSensorMsg = require('./RfidSensorMsg.js');
let ThermalSourceVector = require('./ThermalSourceVector.js');
let SoundSource = require('./SoundSource.js');
let RobotIndexedMsg = require('./RobotIndexedMsg.js');
let CO2SourceVector = require('./CO2SourceVector.js');
let KinematicMsg = require('./KinematicMsg.js');
let ThermalSensorMeasurementMsg = require('./ThermalSensorMeasurementMsg.js');
let SoundSourceVector = require('./SoundSourceVector.js');
let SonarSensorMsg = require('./SonarSensorMsg.js');
let FootprintMsg = require('./FootprintMsg.js');
let RfidTag = require('./RfidTag.js');
let CO2Source = require('./CO2Source.js');
let CO2SensorMsg = require('./CO2SensorMsg.js');
let CO2SensorMeasurementMsg = require('./CO2SensorMeasurementMsg.js');
let Noise = require('./Noise.js');
let LaserSensorMsg = require('./LaserSensorMsg.js');
let RobotIndexedVectorMsg = require('./RobotIndexedVectorMsg.js');
let SoundSensorMsg = require('./SoundSensorMsg.js');
let SoundSensorMeasurementMsg = require('./SoundSensorMeasurementMsg.js');
let ThermalSource = require('./ThermalSource.js');
let RobotMsg = require('./RobotMsg.js');
let RfidSensorMeasurementMsg = require('./RfidSensorMeasurementMsg.js');
let RegisterRobotActionGoal = require('./RegisterRobotActionGoal.js');
let SpawnRobotGoal = require('./SpawnRobotGoal.js');
let RegisterRobotActionResult = require('./RegisterRobotActionResult.js');
let SpawnRobotActionGoal = require('./SpawnRobotActionGoal.js');
let DeleteRobotGoal = require('./DeleteRobotGoal.js');
let RegisterRobotFeedback = require('./RegisterRobotFeedback.js');
let RegisterRobotResult = require('./RegisterRobotResult.js');
let DeleteRobotActionGoal = require('./DeleteRobotActionGoal.js');
let SpawnRobotActionFeedback = require('./SpawnRobotActionFeedback.js');
let RegisterRobotAction = require('./RegisterRobotAction.js');
let SpawnRobotActionResult = require('./SpawnRobotActionResult.js');
let SpawnRobotFeedback = require('./SpawnRobotFeedback.js');
let SpawnRobotAction = require('./SpawnRobotAction.js');
let SpawnRobotResult = require('./SpawnRobotResult.js');
let RegisterRobotActionFeedback = require('./RegisterRobotActionFeedback.js');
let RegisterRobotGoal = require('./RegisterRobotGoal.js');
let DeleteRobotFeedback = require('./DeleteRobotFeedback.js');
let DeleteRobotAction = require('./DeleteRobotAction.js');
let DeleteRobotActionResult = require('./DeleteRobotActionResult.js');
let DeleteRobotResult = require('./DeleteRobotResult.js');
let DeleteRobotActionFeedback = require('./DeleteRobotActionFeedback.js');

module.exports = {
  RfidTagVector: RfidTagVector,
  ThermalSensorMsg: ThermalSensorMsg,
  RfidSensorMsg: RfidSensorMsg,
  ThermalSourceVector: ThermalSourceVector,
  SoundSource: SoundSource,
  RobotIndexedMsg: RobotIndexedMsg,
  CO2SourceVector: CO2SourceVector,
  KinematicMsg: KinematicMsg,
  ThermalSensorMeasurementMsg: ThermalSensorMeasurementMsg,
  SoundSourceVector: SoundSourceVector,
  SonarSensorMsg: SonarSensorMsg,
  FootprintMsg: FootprintMsg,
  RfidTag: RfidTag,
  CO2Source: CO2Source,
  CO2SensorMsg: CO2SensorMsg,
  CO2SensorMeasurementMsg: CO2SensorMeasurementMsg,
  Noise: Noise,
  LaserSensorMsg: LaserSensorMsg,
  RobotIndexedVectorMsg: RobotIndexedVectorMsg,
  SoundSensorMsg: SoundSensorMsg,
  SoundSensorMeasurementMsg: SoundSensorMeasurementMsg,
  ThermalSource: ThermalSource,
  RobotMsg: RobotMsg,
  RfidSensorMeasurementMsg: RfidSensorMeasurementMsg,
  RegisterRobotActionGoal: RegisterRobotActionGoal,
  SpawnRobotGoal: SpawnRobotGoal,
  RegisterRobotActionResult: RegisterRobotActionResult,
  SpawnRobotActionGoal: SpawnRobotActionGoal,
  DeleteRobotGoal: DeleteRobotGoal,
  RegisterRobotFeedback: RegisterRobotFeedback,
  RegisterRobotResult: RegisterRobotResult,
  DeleteRobotActionGoal: DeleteRobotActionGoal,
  SpawnRobotActionFeedback: SpawnRobotActionFeedback,
  RegisterRobotAction: RegisterRobotAction,
  SpawnRobotActionResult: SpawnRobotActionResult,
  SpawnRobotFeedback: SpawnRobotFeedback,
  SpawnRobotAction: SpawnRobotAction,
  SpawnRobotResult: SpawnRobotResult,
  RegisterRobotActionFeedback: RegisterRobotActionFeedback,
  RegisterRobotGoal: RegisterRobotGoal,
  DeleteRobotFeedback: DeleteRobotFeedback,
  DeleteRobotAction: DeleteRobotAction,
  DeleteRobotActionResult: DeleteRobotActionResult,
  DeleteRobotResult: DeleteRobotResult,
  DeleteRobotActionFeedback: DeleteRobotActionFeedback,
};
