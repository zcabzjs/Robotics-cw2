
"use strict";

let MapUpdate = require('./MapUpdate.js');

module.exports = {
  MapUpdate: MapUpdate,
};
